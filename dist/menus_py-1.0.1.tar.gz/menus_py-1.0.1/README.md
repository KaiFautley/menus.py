# menus.py
Simple library for creating text-based menus